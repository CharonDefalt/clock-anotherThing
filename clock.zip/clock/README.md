# Analog Clock

Analog and Digital clock with HTML, CSS and JavaScript

# [See on Codepen](https://codepen.io/hicoders/pen/xxRJoYQ)

![Preview](preview.png)
