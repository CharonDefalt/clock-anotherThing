# Slide Input

## [See Live](https://codepen.io/hicoders/pen/xxYbyRN)

# Preview

![Preview](../.github/assets/slide-input.png)
