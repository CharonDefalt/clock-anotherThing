# Expandable

## [See Live](https://codepen.io/hicoders/pen/bGLVQpY)

# Preview

![Preview](../.github/assets/expandable.png)
