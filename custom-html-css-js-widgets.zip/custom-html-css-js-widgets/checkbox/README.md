# Custom Checkbox

## [See Live](https://codepen.io/hicoders/pen/MWQWrPG)

# Preview

![Preview](../.github/assets/checkbox.png)
