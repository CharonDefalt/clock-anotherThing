# Custom HTML & CSS Switch

### [See Live](https://codepen.io/hicoders/pen/GRyVjVy)

## Screenshot

![](../.github/assets/switch.png)
