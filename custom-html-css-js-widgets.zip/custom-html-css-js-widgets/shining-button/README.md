# Shine Hover Effect

## [See Live](https://codepen.io/hicoders/pen/mdXvGJy)

# Preview

![Preview](../.github/assets/shine-hover-effect.png)
